<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'vthallam');
define('DB_PASSWORD', 'MobileApp123');
define('DB_HOST', 'jobsplane.cngwtgfvvaab.us-west-2.rds.amazonaws.com:3306');
define('DB_NAME', 'Jobsplane');

?>
